package lepirda.damon.g1093.factory;

public enum UserType {
	CLIENT, COURIER
}
