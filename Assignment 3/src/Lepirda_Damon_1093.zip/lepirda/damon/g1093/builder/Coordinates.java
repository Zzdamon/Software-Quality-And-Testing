package lepirda.damon.g1093.builder;

public class Coordinates {
	double lat;
	double lng;
	public double getLat() {
		return lat;
	}
	public double getLng() {
		return lng;
	}
	public Coordinates(double lat, double lng) {
		super();
		this.lat = lat;
		this.lng = lng;
	}
	
	
}
