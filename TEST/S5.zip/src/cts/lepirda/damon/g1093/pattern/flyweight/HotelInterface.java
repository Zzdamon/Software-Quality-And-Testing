package cts.lepirda.damon.g1093.pattern.flyweight;

import java.util.ArrayList;

public interface HotelInterface {
	public void displayGallery(ArrayList<GalleryImage> images);
}
