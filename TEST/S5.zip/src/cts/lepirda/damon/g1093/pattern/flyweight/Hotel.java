package cts.lepirda.damon.g1093.pattern.flyweight;

import java.util.ArrayList;

public class Hotel implements HotelInterface{

	@Override
	public void displayGallery(ArrayList<GalleryImage> images) {
		System.out.println("gallery display");
		
	}

}
