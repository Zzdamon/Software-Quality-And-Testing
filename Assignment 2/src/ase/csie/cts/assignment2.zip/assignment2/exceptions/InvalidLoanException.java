package ase.csie.cts.assignment2.exceptions;

public class InvalidLoanException extends Exception{
	
}
