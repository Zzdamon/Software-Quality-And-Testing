package lepirda.damon.g1093.builder;

public class Restaurant {

	String name;
	String address;
	int minOrder;
	double lat;
	double lng;
	
	
	
}
