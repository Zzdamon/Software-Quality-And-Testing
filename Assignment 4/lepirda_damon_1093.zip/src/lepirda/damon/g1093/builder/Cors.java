package lepirda.damon.g1093.builder;

public class Cors implements ServiceInterface{

	@Override
	public void runService() {
		System.out.println("Cors is running");
		
	}

}
