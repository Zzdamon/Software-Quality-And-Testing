package lepirda.damon.g1093.builder;

public interface ServiceInterface {
	public void runService();
}
