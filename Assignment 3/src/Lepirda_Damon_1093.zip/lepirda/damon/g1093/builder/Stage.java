package lepirda.damon.g1093.builder;

public enum Stage {
	WAITING, TAKEN_BY_COURIER, TAKEN_FROM_RESTAURANT, DELIVERED
}
