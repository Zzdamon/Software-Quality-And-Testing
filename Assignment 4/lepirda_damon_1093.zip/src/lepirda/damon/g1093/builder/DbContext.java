package lepirda.damon.g1093.builder;

public class DbContext implements ServiceInterface{

	@Override
	public void runService() {
		System.out.println("DbContext is running");
	}

}
