package ase.csie.cts.assignment2.services;

public interface MonthlyPaymentInterface {
	public double getMonthlyPayment(double loanValue, double monthlyPercentRate);
}
