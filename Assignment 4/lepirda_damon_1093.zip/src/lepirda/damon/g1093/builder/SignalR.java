package lepirda.damon.g1093.builder;

public class SignalR implements ServiceInterface {

	@Override
	public void runService() {
		System.out.println("SignalR is running");
		
	}

}
