package lepirda.damon.g1093.singleton;

public class TestDatabaseConnection {

	public static void main(String[] args) {	
		
		DatabaseConnection connection1= DatabaseConnection.getDatabaseConnection();
//		DatabaseConnection connection2= new DatabaseConnection();
	}

}
