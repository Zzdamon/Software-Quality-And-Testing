package cts.lepirda.damon.g1093.pattern.factory;

public enum BookingType {
	CONCERT, MUSEUM
}
