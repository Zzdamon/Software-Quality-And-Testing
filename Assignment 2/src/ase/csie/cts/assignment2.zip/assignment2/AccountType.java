package ase.csie.cts.assignment2;

public enum AccountType {
	STANDARD, BUDGET, PREMIUM, SUPER_PREMIUM;
}
